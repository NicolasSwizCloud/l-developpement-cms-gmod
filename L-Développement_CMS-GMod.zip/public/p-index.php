<?php
session_start();

$page = "../includes/bdd.php";

include($page);


// J'inclue la base de données

// Titre

$titre = $bdd->query('SELECT * FROM tbl_textes WHERE id = 1');
$titre = $titre->fetch();

// Fin du titre

// Bouton 

$bouton1 = $bdd->query('SELECT * FROM tbl_bouton WHERE id = 1');
$bouton1 = $bouton1->fetch();

$bouton2 = $bdd->query('SELECT * FROM tbl_bouton WHERE id = 2');
$bouton2 = $bouton2->fetch();

$bouton3 = $bdd->query('SELECT * FROM tbl_bouton WHERE id = 3');
$bouton3 = $bouton3->fetch();

// Fin Bouton

// Bulles

$bulle1 = $bdd->query('SELECT * FROM tbl_textes WHERE id = 2');
$bulle1 = $bulle1->fetch();

$bulle2 = $bdd->query('SELECT * FROM tbl_textes WHERE id = 3');
$bulle2 = $bulle2->fetch();

$bulle3 = $bdd->query('SELECT * FROM tbl_textes WHERE id = 4');
$bulle3 = $bulle3->fetch();

// Fin Bulles

// Infos Serveur

$ip = $bdd->query('SELECT * FROM tbl_textes WHERE id = 5');
$ip = $ip->fetch();

// Fin Infos

?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title><?= $titre['title']; ?></title>

    <!-- Favicon -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Stylesheet -->
    <link rel="stylesheet" href="../assets/style.css">

</head>

<body>
    <!-- Preloader -->
    <div class="preloader d-flex align-items-center justify-content-center">
        <div class="spinner">
            <div class="bounce1"></div>
            <div class="bounce2"></div>
            <div class="bounce3"></div>
        </div>
    </div>

    <!-- ##### Header Area Start ##### -->
    <header class="header-area wow fadeInDown" data-wow-delay="500ms">
        <!-- Top Header Area -->
        <div class="top-header-area">
            <div class="container h-100">
                <div class="row h-100 align-items-center">
                    <div class="col-12 d-flex align-items-center justify-content-between">
                        <!-- Logo Area -->
                        <div class="logo">
                            <a href="index.php"><h3><?= $titre['title']; ?></h3></a>
                        </div>

                        <!-- Search & Login Area -->
                        <div class="search-login-area d-flex align-items-center">
                            <!-- Top Search Area -->
                            <div class="top-search-area">
                                <form action="#" method="post">
                                    <input type="search" name="top-search" id="topSearch" placeholder="Recherche...">
                                    <button type="submit" class="btn"><i class="fa fa-search"></i></button>
                                </form>
                            </div>
                            <!-- Login Area -->
                            <?php
                            if(isset($_SESSION['id'])) { ?>

                            <div class="login-area">

                                <a href="Administration">

                                    <span>Administration</span>

                                 <i class="fa fa-lock" aria-hidden="true"></i>

                             </a>

                            </div>
                            <?php }else{ ?>
                            <div class="login-area">

                                <a href="../install/login.php">

                                    <span>Connexion</span> 

                                    <i class="fa fa-lock" aria-hidden="true"></i>

                                </a>
                            <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Navbar Area -->
        <div class="egames-main-menu" id="sticker">
            <div class="classy-nav-container breakpoint-off">
                <div class="container">
                    <!-- Menu -->
                    <nav class="classy-navbar justify-content-between" id="egamesNav">

                        <!-- Navbar Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">

                            <!-- Close Button -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <!-- Nav Start -->
                            <div class="classynav">
                                <ul>
                                    <li><a href="index.php">Accueil</a></li>
                                    <li><a href="<?= $bouton1['direction']; ?>"><?= $bouton1['nom']; ?></a></li>
                                    <li><a href="<?= $bouton2['direction']; ?>"><?= $bouton2['nom']; ?></a></li>
                                    <li><a href="<?= $bouton3['direction']; ?>"><?= $bouton3['nom']; ?></a></li>
                                </ul>
                            </div>
                            <!-- Nav End -->
                        </div>

                        <!-- Top Social Info -->
                        <div class="top-social-info">
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- ##### Header Area End ##### -->

    <!-- ##### Hero Area Start ##### -->
    <div class="hero-area">
        <!-- Hero Post Slides -->
        <div class="hero-post-slides owl-carousel">

            <!-- Single Slide -->
            <div class="single-slide bg-img bg-overlay" style="background-image: url(https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ0QeXUx9R3vmxXAGXcD-HEgtxruvT8c4HYGndh1F7KJV8v0AqKJQ&s);">
                <!-- Blog Content -->
                <div class="container h-100">
                    <div class="row h-100 align-items-center">
                        <div class="col-12 col-lg-9">
                            <div class="blog-content" data-animation="fadeInUp" data-delay="100ms">
                                <h2 data-animation="fadeInUp" data-delay="400ms"><?= $titre['title']; ?></h2>
                                <p data-animation="fadeInUp" data-delay="700ms">
                                    <?= $titre['description']; ?>

                                    <br />

                                    <br />
                                    <div>
                                            <a class="btn btn-primary" href="<?= $ip['title']; ?>">Connexion au serveur</a>
                                        </div>
                                    </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Hero Area End ##### -->

    <!-- ##### Games Area Start ##### -->
    <div class="games-area section-padding-100-0">
        <div class="container">
            <div class="row">
                <!-- Single Games Area -->
                <div class="col-12 col-md-4">
                    <div class="single-games-area text-center mb-100 wow fadeInUp" data-wow-delay="100ms">
                        <h3><?= $bulle1['title']; ?></h3>
                        <h4><details><?= $bulle1['description']; ?></details></h4>
                    </div>
                </div>

                <!-- Single Games Area -->
                <div class="col-12 col-md-4">
                    <div class="single-games-area text-center mb-100 wow fadeInUp" data-wow-delay="300ms">
                        <h3><?= $bulle2['title']; ?></h3>
                        <h4><details><?= $bulle2['description']; ?></details></h4>
                    </div>
                </div>

                <!-- Single Games Area -->
                <div class="col-12 col-md-4">
                    <div class="single-games-area text-center mb-100 wow fadeInUp" data-wow-delay="500ms">
                        <h3><?= $bulle3['title']; ?></h3>
                        <h4><details><?= $bulle3['description']; ?></details></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Games Area End ##### -->

    
    <footer class="footer-area">
        <!-- Main Footer Area -->
        <div class="main-footer-area section-padding-100-0">
            <div class="container">
                <div class="row">
                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="single-footer-widget mb-70 wow fadeInUp" data-wow-delay="100ms">
                            <div class="widget-title">
                                <a href="index.php"><p><?= $titre['title']; ?></p></a>
                            </div>
                            <div class="widget-content">
                                <p><?= $titre['description']; ?></p>
                            </div>
                        </div>
                    </div>
        <!-- Copywrite Area -->
        <div class="copywrite-content">
            <div class="container h-100">
                <div class="row h-100 align-items-center">
                    <div class="col-12 col-sm-5">
                        <!-- Copywrite Text -->
                        <p class="copywrite-text">
                            Copyright &copy;
                            2019 - <?php echo date("Y"); ?>
                            Tous Droits Réservé <a href="https://web8456.holycloud.fr/" target="_blank">L-Développement</a> | Template by <a href="https://colorlib.com" target="_blank">Colorlib</a>
                        </p>
                      </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ##### Footer Area End ##### -->

    <!-- ##### All Javascript Script ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="../assets/js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="../assets/js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="../assets/js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="../assets/js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="../assets/js/active.js"></script>
</body>

</html>