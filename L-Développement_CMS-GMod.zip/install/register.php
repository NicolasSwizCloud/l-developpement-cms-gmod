<?php



include('includes/head.php');



include('../includes/bdd.php');



 if (isset($_SESSION['id']))  {



        echo '<script language="javascript">document.location="/Administration/"</script>'; 



    }







if(isset($_POST['create_account'])){



    /*Set-Up des variables récupérées dans le formulaire */



    extract($_POST);







    $prenom = htmlspecialchars($prenom);







    $nom = htmlspecialchars($nom);







    $mail = htmlspecialchars($mail);







    $pass = password_hash($pass1, PASSWORD_DEFAULT);







    $passVerify = password_hash($pass2, PASSWORD_DEFAULT);







    $passNoHash = htmlspecialchars($pass1);







    $passNoHash2 = htmlspecialchars($pass2);







    $passLenght = strlen($passNoHash);

























    if(!empty($prenom) AND !empty($nom) AND !empty($mail) AND !empty($pass) AND !empty($passVerify)){







        if($passLenght > 6){







            if(filter_var($mail, FILTER_VALIDATE_EMAIL)){







                $reqMail = $bdd -> prepare('SELECT * FROM MEMBRES WHERE MAIL = ?');



                $reqMail->execute(array($mail));







                if($reqMail->rowCount() == 0){







                if($passNoHash == $passNoHash2){



                    $error = "<div class='alert alert-success'><b>Bravo !</b> Inscription réussit !</div>";



                    //Insertion dans la base de données



                    $insert = $bdd -> prepare('INSERT INTO `MEMBRES`( `NOM`, `PRENOM`, `MAIL`, `PASSWORD`, `DATE_INSCRIPTION`, `GRADE`) VALUES (?,?,?,?,NOW(),?)');



                    $insert->execute(array($nom, $prenom, $mail, $pass, "MEMBRE"));



                }else{



                    $error = "<div class='alert alert-danger'><b>Erreur !</b> Vos mots de passe ne correspondandes pas ! </div>";



                }



            }else{



                $error = "<div class='alert alert-danger'><b>Erreur !</b> Votre E-Mail est déjà utilisé pour un autre comptes !</div>";



            }



            }else{



                $error = "<div class='alert alert-danger'><b>Erreur !</b> Veuillez saisir un E-Mail valide !</div>";



            }



        }else{



            $error = "<div class='alert alert-danger'><b>Erreur !</b> Votre mot de passe doit contenir 8 caractères minumum !(". $passLenght .")</div>";



        }



    }else{



        $error = "<div class='alert alert-danger'><b>Erreur !</b> Veuillez saisir tout les champs !</div>";



    }



}



?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div class="main">

        <h1>Inscription</h1>
        <div class="container">
            <div class="sign-up-content">
                <?php if(isset($error)){echo $error;}?>
                <form method="POST" class="signup-form">
                    <h2 class="form-title">A Supprimer après inscription?</h2>
                    <div class="form-radio">
                    <a type="radio" name="member_level" value="average" id="average" href="login.php">
                        <label for="average">Connexion</label>
                    </a>
                    </div>

                    <div class="form-textbox">
                        <label for="prenom">Prénom</label>
                        <input type="text" name="prenom" id="prenom" />
                    </div>

                    <div class="form-textbox">
                        <label for="nom">Nom</label>
                        <input type="text" name="nom" id="nom" />
                    </div>

                    <div class="form-textbox">
                        <label for="mail">Email</label>
                        <input type="email" name="mail" id="mail" />
                    </div>

                    <div class="form-textbox">
                        <label for="pass1">Mot de passe</label>
                        <input type="password" name="pass1" id="pass1" />
                    </div>

                    <div class="form-textbox">
                        <label for="pass2">Confirmation du mot de passe</label>
                        <input type="password" name="pass2" id="pass2" />
                    </div>

                    <div class="form-textbox">
                        <input type="submit" name="create_account" id="create_account" class="submit" value="Inscription" />
                    </div>
                </form>
            </div>
        </div>

    </div>

    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>