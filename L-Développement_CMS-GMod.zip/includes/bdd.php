<?php


// Je me connecte à la base de données

try
{
	$bdd = new PDO('mysql:host=localhost;dbname=NOM-DE-LA-BDD;charset=utf8', 'USERNAME', 'PASSWORD');
}
catch (Exception $e)
{
        die('Erreur avec MySQL : ' . $e->getMessage());
}
?>