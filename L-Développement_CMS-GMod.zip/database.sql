-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le :  Dim 22 déc. 2019 à 20:12
-- Version du serveur :  10.3.21-MariaDB-1:10.3.21+maria~stretch
-- Version de PHP :  7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `PLESK85647_CMS`
--

-- --------------------------------------------------------

--
-- Structure de la table `MEMBRES`
--

CREATE TABLE `MEMBRES` (
  `id` int(11) NOT NULL,
  `NOM` varchar(255) NOT NULL,
  `PRENOM` varchar(255) NOT NULL,
  `MAIL` varchar(255) NOT NULL,
  `PASSWORD` varchar(255) NOT NULL,
  `DATE_INSCRIPTION` text NOT NULL,
  `GRADE` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `MEMBRES`
--

INSERT INTO `MEMBRES` (`id`, `NOM`, `PRENOM`, `MAIL`, `PASSWORD`, `DATE_INSCRIPTION`, `GRADE`) VALUES
(444, 'Baud', 'Nicolas', 'boutiquegamer53@gmail.com', '$2y$10$zrAgHYM1H3tArREI/.3z/elOPsK3sXffGuMB52E5JATjNg6aQWvV6', '2019-12-09 16:52:27', 'admin'),
(448, 'Baud', 'Nicolas', 'nicolaslevrai322@gmail.com', '$2y$10$A9S7TpgWKUoj0k58ZcZmLeLsZrMLqqTSn3QBHbJA7zG6/8reMtitO', '2019-12-22 19:54:09', 'MEMBRE');

-- --------------------------------------------------------

--
-- Structure de la table `tbl_bouton`
--

CREATE TABLE `tbl_bouton` (
  `id` text NOT NULL,
  `nom` text NOT NULL,
  `direction` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tbl_bouton`
--

INSERT INTO `tbl_bouton` (`id`, `nom`, `direction`) VALUES
('1', 'Bouton 1', 'boutique'),
('2', 'Bouton 2', '../forum'),
('3', 'Bouton 3', 'Direction 3');

-- --------------------------------------------------------

--
-- Structure de la table `tbl_textes`
--

CREATE TABLE `tbl_textes` (
  `id` text NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tbl_textes`
--

INSERT INTO `tbl_textes` (`id`, `title`, `description`) VALUES
('1', 'Mon Serveur GMod', 'Description du serveur GMod'),
('2', 'Bulle 1', 'Desc Bulle 1'),
('3', 'Bulle 2', 'Desc Bulle 2'),
('4', 'Bulle 3', 'Desc Bulle 3'),
('5', 'steam:connect:IP DU SERVEUR', 'Aucune Description nécessaire ');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `MEMBRES`
--
ALTER TABLE `MEMBRES`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `MEMBRES`
--
ALTER TABLE `MEMBRES`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=449;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
